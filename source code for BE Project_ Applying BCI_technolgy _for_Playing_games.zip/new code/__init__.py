import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('model.csv')
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.23, random_state = 0)
print(X_train)
print(y_train)
print(X_test)
print(y_test)
print(type(y_test[0]))

# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)
print(X_train)
print(X_test)


from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0)
classifier.fit(X_train, y_train)

y_pred = classifier.predict(X_test)
print(np.concatenate((y_pred.reshape(len(y_pred),1), y_test.reshape(len(y_test),1)),1))

# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix, accuracy_score
cm = confusion_matrix(y_test, y_pred)
print(cm)
accuracy_score(y_test, y_pred)



from NeuroPy import NeuroPy
from time import sleep
import csv
import pickle
neuropy = NeuroPy("COM3",57600)
#model = pickle.load(open('random_forest_regression_model.pkl', 'rb'))
# =============================================================================
# variables 
# =============================================================================
m_value = []
a_value = []
lA_value = []
hA_value = []
lB_value = []
hB_value = []
lG_value = []
mG_value = []
# =============================================================================
# attention
# =============================================================================
def attention_callback(attention_value):
    """this function will be called everytime NeuroPy has a new value for attention"""
    value = attention_value
    a_value.append(value)
#    attention_value.append(value)
    print ("Value of attention is: ", value)
    return value
# =============================================================================
# meditation
# =============================================================================
def meditation_callback(meditation_value):
    """this function will be called everytime NeuroPy has a new value for meditation"""
    value = meditation_value
    m_value.append(value)
#    meditation_list.append(value)
    print ("Value of meditation is: ", value)
    return value
# =============================================================================
# low Alpha
# =============================================================================
def lowAlpha_callback(lowAlpha_value):
    """this function will be called everytime NeuroPy has a new value for lowAlpha"""
    value = neuropy.lowAlpha
    lA_value.append(value)
#    lowAlpha_list.append(value)
    print ("Value of lowAlpha is: ", value)
    return value
# =============================================================================
# high ALpha
# =============================================================================
def highAlpha_callback(highAlpha_value):
    """this function will be called everytime NeuroPy has a new value for highAlpha"""
    value = neuropy.highAlpha
    hA_value.append(value)
#    highAlpha_list.append(value)
    print ("Value of highAlpha is: ", value)
    return value
# =============================================================================
# low Beta
# =============================================================================
def lowBeta_callback(lowBeta_value):
     """this function will be called everytime NeuroPy has a new value for lowBeta"""
     value = neuropy.lowBeta
     lB_value.append(value)
#     lowBeta_list.append(value)
     print ("Value of lowBeta is: ", value)
     return value
# =============================================================================
# high Beta
# =============================================================================
def highBeta_callback(highBeta_value):
    """this function will be called everytime NeuroPy has a new value for highBeta"""
    value = neuropy.highBeta
    hB_value.append(value)
#    highBeta_list.append(value)
    print ("Value of highBeta is: ", value)
    return value
# =============================================================================
#  low Gamma
# =============================================================================
def lowGamma_callback(lowGamma_value):
    """this function will be called everytime NeuroPy has a new value for lowGamma"""
    value = neuropy.lowGamma
    lG_value.append(value)
#    lowGamma_list.append(value)
    print ("Value of lowGamma is: ", value)
    return value
# =============================================================================
# high Gamma
# =============================================================================
def midGamma_callback(midGamma_value):
    """this function will be called everytime NeuroPy has a new value for midGamma"""
    value = neuropy.midGamma
    mG_value.append(value)
#    midGamma_list.append(value)
    print ("Value of midGamma is: ", value)
    return value

a1 = neuropy.setCallBack("attention", attention_callback)
a2 = neuropy.setCallBack("meditation", meditation_callback)
a3 = neuropy.setCallBack("lowAlpha", lowAlpha_callback)
a4 = neuropy.setCallBack("highAlpha", highAlpha_callback)
a5 = neuropy.setCallBack("lowBeta", lowBeta_callback)
a6 = neuropy.setCallBack("highBeta", highBeta_callback)
a7 = neuropy.setCallBack("lowGamma", lowGamma_callback)
a8 = neuropy.setCallBack("midGamma", midGamma_callback)

inputSignal = []
model_predict = []
neuropy.start()
try:
    while True:
        pred = [[neuropy.attention,neuropy.meditation,neuropy.lowAlpha,neuropy.highAlpha,neuropy.lowBeta,neuropy.highBeta,neuropy.lowGamma,neuropy.midGamma]]
        print(pred)
        pred = classifier.predict(sc.transform(pred))
#        model_predict.append(pred)
        print('Prediction:', pred)
        sleep(1.0)
finally:
    neuropy.stop()
# =============================================================================
# 
# dataset = [["Attention", "Meditation", "lowAlpha", "highAlpha", "lowBeta", "highBeta", "lowGamma", "midGamma","output"]]
# for i in range(0,len(m_value)):
#     dataset.append([a_value[i],m_value[i],lA_value[i],hA_value[i],lB_value[i],hB_value[i],lG_value[i],mG_value[i],model_predict[i]])
#  
# with open('practice_test.csv', 'w', newline='') as csv_1:
#   csv_out = csv.writer(csv_1)
#   csv_out.writerows(dataset)
# 
# 
# 
# =============================================================================
