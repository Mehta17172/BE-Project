# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 09:04:43 2021

@author: dell
"""
from keras.models import Sequential
from keras.layers import Dense,Activation,Flatten,Dropout
from keras.layers import Conv2D,MaxPooling2D
from keras.callbacks import ModelCheckpoint

import tensorflow as tf

# class myCallback(tf.keras.callbacks.Callback):
#   def on_epoch_end(self, epoch, logs={}):
#     if(logs.get('accuracy')>0.6):
#       print("\nReached 60% accuracy so cancelling training!")
#       self.model.stop_training = True

# mnist = tf.keras.datasets.fashion_mnist

# (x_train, y_train),(x_test, y_test) = mnist.load_data()
# x_train, x_test = x_train / 255.0, x_test / 255.0

# callbacks = myCallback()
import pandas as pd
dataset = pd.read_csv('/content/drive/MyDrive/Colab Notebooks/python game master/model.csv')
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size = 0.23, random_state = 0)

model = tf.keras.models.Sequential([
  # tf.keras.layers.Flatten(input_shape=(28, 28)),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(300, activation=tf.nn.relu),
  tf.keras.layers.Dense(300, activation=tf.nn.relu),
  tf.keras.layers.Dense(300, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(200, activation=tf.nn.relu),
  tf.keras.layers.Dense(200, activation=tf.nn.relu),
  tf.keras.layers.Dense(300, activation=tf.nn.relu),
  tf.keras.layers.Dense(250, activation=tf.nn.relu),
  tf.keras.layers.Dense(200, activation=tf.nn.relu),
  tf.keras.layers.Dense(5, activation=tf.nn.softmax)
])
model.compile(optimizer=tf.optimizers.Adam(),
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])
checkpoint = ModelCheckpoint('model-{epoch:03d}.model',monitor='val_loss',verbose=0,save_best_only=True,mode='auto')
history = model.fit(x_train, y_train, epochs=50, batch_size=10, callbacks=[checkpoint],validation_split=0.2)