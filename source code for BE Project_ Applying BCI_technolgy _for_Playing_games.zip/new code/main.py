# -*- coding: utf-8 -*-
"""
Created on Fri Apr 30 06:32:48 2021

@author: dell
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 13:53:25 2021

@author: dell
"""

# =============================================================================
# Model Training
# =============================================================================
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

dataset = pd.read_csv('model.csv')
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.23, random_state = 0)
print(X_train)
print(y_train)
print(X_test)
print(y_test)
print(type(y_test[0]))

# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)
print(X_train)
print(X_test)


from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0)
classifier.fit(X_train, y_train)

y_pred = classifier.predict(X_test)
print(np.concatenate((y_pred.reshape(len(y_pred),1), y_test.reshape(len(y_test),1)),1))

# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix, accuracy_score
cm = confusion_matrix(y_test, y_pred)
print(cm)
accuracy_score(y_test, y_pred)



# =============================================================================
# NeurosKy Reading function
# =============================================================================

from NeuroPy import NeuroPy
from time import sleep
import csv

neuropy = NeuroPy("COM3",57600)

# =============================================================================
# variables 
# =============================================================================
meditation_value = 0
attention_value = 0
lowAlpha_value = 0
highAlpha_value = 0
lowBeta_value = 0
highBeta_value = 0
lowGamma_value = 0
midGamma_value = 0
# =============================================================================
# attention
# =============================================================================
from NeuroPy import NeuroPy
from time import sleep
import csv
import pickle
neuropy = NeuroPy("COM3",57600)
#model = pickle.load(open('random_forest_regression_model.pkl', 'rb'))
# =============================================================================
# variables 
# =============================================================================
m_value = []
a_value = []
lA_value = []
hA_value = []
lB_value = []
hB_value = []
lG_value = []
mG_value = []
# =============================================================================
# attention
# =============================================================================
def attention_callback(attention_value):
    """this function will be called everytime NeuroPy has a new value for attention"""
    value = attention_value
    a_value.append(value)
#    attention_value.append(value)
    print ("Value of attention is: ", value)
    return value
# =============================================================================
# meditation
# =============================================================================
def meditation_callback(meditation_value):
    """this function will be called everytime NeuroPy has a new value for meditation"""
    value = meditation_value
    m_value.append(value)
#    meditation_list.append(value)
    print ("Value of meditation is: ", value)
    return value
# =============================================================================
# low Alpha
# =============================================================================
def lowAlpha_callback(lowAlpha_value):
    """this function will be called everytime NeuroPy has a new value for lowAlpha"""
    value = neuropy.lowAlpha
    lA_value.append(value)
#    lowAlpha_list.append(value)
    print ("Value of lowAlpha is: ", value)
    return value
# =============================================================================
# high ALpha
# =============================================================================
def highAlpha_callback(highAlpha_value):
    """this function will be called everytime NeuroPy has a new value for highAlpha"""
    value = neuropy.highAlpha
    hA_value.append(value)
#    highAlpha_list.append(value)
    print ("Value of highAlpha is: ", value)
    return value
# =============================================================================
# low Beta
# =============================================================================
def lowBeta_callback(lowBeta_value):
     """this function will be called everytime NeuroPy has a new value for lowBeta"""
     value = neuropy.lowBeta
     lB_value.append(value)
#     lowBeta_list.append(value)
     print ("Value of lowBeta is: ", value)
     return value
# =============================================================================
# high Beta
# =============================================================================
def highBeta_callback(highBeta_value):
    """this function will be called everytime NeuroPy has a new value for highBeta"""
    value = neuropy.highBeta
    hB_value.append(value)
#    highBeta_list.append(value)
    print ("Value of highBeta is: ", value)
    return value
# =============================================================================
#  low Gamma
# =============================================================================
def lowGamma_callback(lowGamma_value):
    """this function will be called everytime NeuroPy has a new value for lowGamma"""
    value = neuropy.lowGamma
    lG_value.append(value)
#    lowGamma_list.append(value)
    print ("Value of lowGamma is: ", value)
    return value
# =============================================================================
# high Gamma
# =============================================================================
def midGamma_callback(midGamma_value):
    """this function will be called everytime NeuroPy has a new value for midGamma"""
    value = neuropy.midGamma
    mG_value.append(value)
#    midGamma_list.append(value)
    print ("Value of midGamma is: ", value)
    return value

a1 = neuropy.setCallBack("attention", attention_callback)
a2 = neuropy.setCallBack("meditation", meditation_callback)
a3 = neuropy.setCallBack("lowAlpha", lowAlpha_callback)
a4 = neuropy.setCallBack("highAlpha", highAlpha_callback)
a5 = neuropy.setCallBack("lowBeta", lowBeta_callback)
a6 = neuropy.setCallBack("highBeta", highBeta_callback)
a7 = neuropy.setCallBack("lowGamma", lowGamma_callback)
a8 = neuropy.setCallBack("midGamma", midGamma_callback)

# =============================================================================
# neuropy.start()
# try:
#     while True:
#         pred = [[neuropy.attention,neuropy.meditation,neuropy.lowAlpha,neuropy.highAlpha,neuropy.lowBeta,neuropy.highBeta,neuropy.lowGamma,neuropy.midGamma]]
#         print(pred)
#         pred = classifier.predict(sc.transform(pred))
# #        model_predict.append(pred)
#         print('Prediction:', pred)
#         sleep(1.0)
# finally:
#     neuropy.stop()
# =============================================================================


# =============================================================================
# Maze Game design
# =============================================================================
from graph import Graph
from character import Character
import ui_file
import astar
import random
import pygame
import time
import queue
from collections import deque
import os
# function to set the position of the display window
def set_window_position(x, y):
	os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (x,y)

# creates a grid of size (size)*(size)
def create_grid(size):

	# create a graph for the grid
	grid = Graph()

	# add the vertices of the grid
	for i in range(size):
		for j in range(size):
			grid.add_vertex((i,j))

	# return the constructed grid
	return grid

# creates a maze when a grid ad its vertices are passed in
def create_maze(grid, vertex, completed=None, vertices=None):
	
	if vertices is None:
		vertices = grid.get_vertices()
	if completed is None:
		completed = [vertex]

	# select a random direction
	paths = list(int(i) for i in range(4))
	random.shuffle(paths)

	# vertices in the direction from current vertex
	up = (vertex[0],vertex[1]-1)
	down = (vertex[0],vertex[1]+1)
	left = (vertex[0]-1,vertex[1])
	right = (vertex[0]+1,vertex[1])

	for direction in paths:
		if direction == 0:
			if up in vertices and up not in completed:
				# add the edges
				grid.add_edge((vertex,up))
				grid.add_edge((up,vertex))
				completed.append(up)
				create_maze(grid, up, completed, vertices)
		elif direction == 1:
			if down in vertices and down not in completed:
				grid.add_edge((vertex,down))
				grid.add_edge((down,vertex))
				completed.append(down)
				create_maze(grid, down, completed, vertices)
		elif direction == 2:
			if left in vertices and left not in completed:
				grid.add_edge((vertex,left))
				grid.add_edge((left,vertex))
				completed.append(left)
				create_maze(grid, left, completed, vertices)
		elif direction == 3:
			if right in vertices and right not in completed:
				grid.add_edge((vertex,right))
				grid.add_edge((right,vertex))
				completed.append(right)
				create_maze(grid, right, completed, vertices)

	return grid

# draw maze function
# takes in a (size)x(size) maze and prints a "colour" path
# side_length is the length of the grid unit and border_width is its border thickness
def draw_maze(screen, maze, size, colour, side_length, border_width):
	# for every vertex in the maze:
	for i in range(size):
		for j in range(size):
			# if the vertex is not at the left-most side of the map
			if (i != 0):
				# check if the grid unit to the current unit's left is connected by an edge
				if maze.is_edge(((i,j),(i-1,j))):
					# if connected, draw the grid unit without the left wall
					pygame.draw.rect(screen,colour,[(side_length+border_width)*i, border_width+(side_length+border_width)*j,\
									 side_length+border_width, side_length])
			# if the vertex is not at the right-most side of the map
			if (i != size-1):
				if maze.is_edge(((i,j),(i+1,j))):
					# draw the grid unit without the right wall (extend by border_width)
					pygame.draw.rect(screen,colour,[border_width+(side_length+border_width)*i,\
									 border_width+(side_length+border_width)*j, side_length+border_width, side_length])
			# if the vertex is not at the top-most side of the map
			if (j != 0):
				if maze.is_edge(((i,j),(i,j-1))):
					pygame.draw.rect(screen,colour,[border_width+(side_length+border_width)*i,\
									 (side_length+border_width)*j, side_length, side_length+border_width])
			# if the vertex is not at the bottom-most side of the map
			if (j != size-1):
				if maze.is_edge(((i,j),(i,j+1))):
					pygame.draw.rect(screen,colour,[border_width+(side_length+border_width)*i,\
									 border_width+(side_length+border_width)*j, side_length, side_length+border_width])

# draw position of grid unit
def draw_position(screen, side_length, border_width, current_point, colour):
	pygame.draw.rect(screen, colour, [border_width+(side_length+border_width)*current_point[0],\
					 border_width+(side_length+border_width)*current_point[1], side_length, side_length])

# run the maze game
# takes in a game mode parameter along with grid size and side length for the maze
def runGame(grid_size, side_length, mode):
    # initialize the game engine
    pygame.init()
	# Defining colours (RGB) ...
    BLACK = (0,0,0)
    GRAY = (100,100,100)
    WHITE = (255,255,255)
    GOLD = (249,166,2)
    GREEN = (0,255,0)
    RED = (255,0,0)
    BLUE = (0,0,255)

	# set the grid size and side length of each grid
	# grid_size = 20 # this is the maximum size before reaching recursion limit on maze buidling function
	# side_length = 10

	# scale the border width with respect to the given side length
    border_width = side_length//5

	# initialize the grid for the maze
    grid = create_grid(grid_size)
	# create the maze using the grid
    maze = create_maze(grid, (grid_size//2,grid_size//2)) # use the starting vertex to be middle of the map

	# Opening a window ...
	# set the screen size to match the grid
    size = (grid_size*(side_length+border_width)+border_width,grid_size*(side_length+border_width)+border_width)
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("\"Esc\" to exit")

	# set the continue flag
    carryOn = True

	# set the clock (how fast the screen updates)
    clock = pygame.time.Clock()

	# have a black background
    screen.fill(BLACK)

	# get all of the vertices in the maze
    vertices = maze.get_vertices()

	# draw the maze
    draw_maze(screen, maze, grid_size, WHITE, side_length, border_width)

	# initialize starting point of character and potential character 2
    start_point = (0,0)
	# opposing corner
	
	# set end-point for the maze
    end_point = (grid_size-1,grid_size-1)
	
	# randomize a start and end point
    choice = random.randrange(4)
    
    if choice == 0:
        start_point = (grid_size-1,grid_size-1)
        end_point = (0,0)
    elif choice == 1:
        start_point = (0,grid_size-1)
        end_point = (grid_size-1,0)
    elif choice == 2:
        start_point = (grid_size-1,0)
        end_point = (0,grid_size-1)
	
	# initialize winner variable
    winner = 0

	# initialize the character
    player1 = Character(screen, side_length, border_width, vertices,start_point, end_point, start_point, GREEN, WHITE)
    
	

	# draw the end-point
    draw_position(screen, side_length, border_width, end_point, RED)
	
	# update the screen
    pygame.display.flip()

	# set cooldown for key presses
    cooldown = 100

	# initialize the cooldown timer
    start_timer = pygame.time.get_ticks()

	# if the two player mode is selected, initialize the cooldown timer for second player
    if mode == 1:
        start_timer2 = pygame.time.get_ticks()

	# initialize game timer for solo mode
    game_timer = 0
	# if solo mode is selected, start game timer
    if mode == 0:
        game_timer = time.time()
    path = astar.astar(start_point,end_point,maze)
    path.remove(start_point)
    print(path)
    print(type(path))
    cnt = 0
    cnt2 = 0
	# main loop
    while carryOn:
        cnt+=1
        sleep(1.0)
		# action (close screen)
        for event in pygame.event.get():
            # user did something
            if event.type == pygame.QUIT:
                carryOn = False
				# mode = -1 means just exit
                mode = -1
            elif event.type == pygame.KEYDOWN:
                #Pressing the Esc Key will quit the game
                if event.key == pygame.K_ESCAPE:
                    carryOn = False
                    neuropy.stop()
                    mode = -1
        pred = [[neuropy.attention,neuropy.meditation,neuropy.lowAlpha,neuropy.highAlpha,neuropy.lowBeta,neuropy.highBeta,neuropy.lowGamma,neuropy.midGamma]]
        pre = classifier.predict(sc.transform(pred))
        keys = pygame.key.get_pressed()
        
        if (pygame.time.get_ticks() - start_timer > cooldown):
			# get the current point of character
            current_point = player1.get_current_position()
            PRN =random.random()
            if(PRN<0.5):
                cnt2+=1
                path = astar.astar(current_point, end_point, maze)
                path.remove(current_point)
                if len(path) == 0:
                    mode = -1
                    carryOn = False
                    neuropy.stop()
                    continue
                next_point = path[0]
                player1.move_character_smooth(next_point,5)
                start_timer = pygame.time.get_ticks()
                if next_point[0] - current_point[0] == 1:
                    a_pred = 2
                elif next_point[0] - current_point[0] == -1:
                    a_pred = 1
                elif next_point[1] - current_point[1] == 1:
                    a_pred = 4
                elif next_point[1] - current_point[1] == -1:
                    a_pred = 3
                print(a_pred)
                continue
			# move character right
            print(pre)
            if keys[pygame.K_RIGHT] or pre == 2:
				# check if the next point is in the maze
                if (current_point[0]+1,current_point[1]) in vertices:
                    next_point = (current_point[0]+1,current_point[1])
					# check if the next point is connected by an edge
                    if (maze.is_edge((current_point,next_point))):
                        player1.move_character_smooth(next_point,5)
                # restart cooldown timer
                start_timer = pygame.time.get_ticks()
			# move character left
            elif keys[pygame.K_LEFT] or pre == 1:
                if (current_point[0]-1,current_point[1]) in vertices:
                    next_point = (current_point[0]-1, current_point[1])
                    if (maze.is_edge((current_point,next_point))):
                        player1.move_character_smooth(next_point,5)
				# restart cooldown timer
                start_timer = pygame.time.get_ticks()
			# move character up
            elif keys[pygame.K_UP] or pre == 3:
                if (current_point[0],current_point[1]-1) in vertices:
                    next_point = (current_point[0], current_point[1]-1)
                    if (maze.is_edge((current_point,next_point))):
                        player1.move_character_smooth(next_point,5)
				# restart cooldown timer
                start_timer = pygame.time.get_ticks()
			# move character down
            elif keys[pygame.K_DOWN] or pre == 4:
                if (current_point[0],current_point[1]+1) in vertices:
                    next_point = (current_point[0], current_point[1]+1)
                    if (maze.is_edge((current_point,next_point))):
                        player1.move_character_smooth(next_point,5)
				# restart cooldown timer
                start_timer = pygame.time.get_ticks()
            
		# win conditions for the different modes
        if mode == 0:
            if player1.reached_goal():
                neuropy.stop()
                carryOn = False
		# limit to 60 frames per second (fps)
        clock.tick(60)

	# stop the game engine once exited the game
    pygame.quit()

	# solo mode
    if mode == 0:
        timer = int(time.time() - game_timer)
        return mode, timer
	# other modes
    else:
        return mode, winner
    
    
    
    
# main function
if __name__ == "__main__":

	# set the window display position
    set_window_position(50,50)

	# initialize states
    states = {0:"Main Menu", 1:"Gameplay"}
    current_state = states[0]
    
	# initialize variables
    grid_size = 0
    side_length = 0
    mode = 0

	# flag for main loop
    Run = True
    while Run:
        if current_state == states[0]:
            Run, grid_size, side_length, mode = ui_file.startScreen()
            current_state = states[1]
        elif current_state == states[1]:
            neuropy.start()
            mode, value = runGame(grid_size, side_length, mode)
            neuropy.stop()
            if mode != -1:
                ui_file.endGame(mode, value)
                current_state = states[0]




# =============================================================================
# libraries
# =============================================================================

# =============================================================================
# 
# 
# neuropy.start()
# try:
#     while True:
# #        print("Blink Stregnth ", neuropy.lowAlpha)
# #        t+=0.2
# #        print(t)
# #        dataset.append([attention_val, meditation_val])
#         sleep(0.2)
# finally:
#     neuropy.stop()
#     
# 
# =============================================================================
#path = astar.astar(start_point2, end_point2, maze) #GIVES ME THE PATH OF THE MAZE