#Read Me
#Topic : Applying BCI Technology for Playing Games
#Points to follow before running the game
1. Make sure you have ThinkGear Connector.exe file downloaded and are using NeuroSky Mindwave as EEG device.
2. Now open your bluetooth connection and pair the NeuroSKy headset with the system.
3. Open main.py  in spyder.
4. Press Ctrl + Enter to run the game.

# In game there are settings were you can change the size and length of the maze.
